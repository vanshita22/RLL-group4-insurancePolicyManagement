package com.insurance.management;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.insurance.management.model.Approvals;
import com.insurance.management.model.Category;
import com.insurance.management.model.Disapproved;
import com.insurance.management.model.Policies;
import com.insurance.management.model.Queries;
import com.insurance.management.model.User;
import com.insurance.management.repository.ApprovalsRepository;
import com.insurance.management.repository.ApprovedRepository;
import com.insurance.management.repository.CategoryRepository;
import com.insurance.management.repository.DisapprovedRepository;
import com.insurance.management.repository.PoliciesRepository;
import com.insurance.management.repository.QueriesRepository;
import com.insurance.management.repository.UserRepository;

@SpringBootTest
class ManagementApplicationTests {
	@Autowired
	private ApprovalsRepository approvalsRepository;
	@Autowired
	private ApprovedRepository approvedRepository;
	@Autowired
	private DisapprovedRepository disapprovedRepository;
	@Autowired
	private CategoryRepository categoryRepository;
	@Autowired
	private PoliciesRepository policiesRepository;
	@Autowired
	private QueriesRepository queriesRepository;
	@Autowired
	private UserRepository userRepository;

									//Mansi
	@Test
	public void addPolicy() {
		Policies policies = new Policies();
		policies.setPolicyName("LIC");
		policies.setCategory("Health");
		policies.setAmount(200000.00);
		policies.setTenureInYears(5);
		policiesRepository.save(policies);
		assertNotNull(policiesRepository.findById("LIC").get());
	}
	
	@Test
	public void getPolicy() {
		Policies policies = policiesRepository.findById("LIC").get();
		assertEquals(5, policies.getTenureInYears());
	}
	
	@Test
	public void policies() {
		List<Policies> list = policiesRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void updatePolicy() {
		Policies policies = policiesRepository.findById("LIC").get();
		policies.setPolicyName("HDFC");
		policies.setCategory("Health");
		policies.setAmount(400000.00);
		policies.setTenureInYears(10);
		policiesRepository.save(policies);
		assertNotEquals(400000.00, policiesRepository.findById("LIC").get().getAmount());
		assertNotEquals("Life", policiesRepository.findById("LIC").get().getPolicyName());
		assertNotEquals("Vehicle", policiesRepository.findById("LIC").get().getCategory());
		assertNotEquals(6, policiesRepository.findById("LIC").get().getTenureInYears());
	}

	
								//Sontosh
	@Test
	public void addUser() {
		User user = new User();
		user.setUserid(1);
		user.setUserName("Sontosh");
		user.setMobile(8692736846L);
		user.setPassword("Son");
		user.setEmail("Son@gmail.com");
		userRepository.save(user);
		assertNotNull(userRepository.findById("Sontosh").get());
	}
	
							//Bhargavi
	@Test
	public void user() {
		List<User> list = userRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void getUser() {
		User user = userRepository.findById("Bhargavi").get();
		assertEquals("Bhargavi", user.getUserName());
	}
	
	@Test
	public void updateUser() {
		User user = userRepository.findById("Bhargavi").get();
		user.setUserName("Bhargavi");
		user.setPassword("Bhargavi@123");
		user.setMobile(9014526883L);
		user.setEmail("Bhargavi@yahoo.com");
		userRepository.save(user);
		assertEquals("Bhargavi", userRepository.findById("Bhargavi").get().getUserName());
		assertNotEquals(475866328L, userRepository.findById("Bhargavi").get().getMobile());
		assertNotEquals("14585", userRepository.findById("Bhargavi").get().getPassword());
		assertNotEquals("pr@gmail.com", userRepository.findById("Bhargavi").get().getPassword());
	}

	
								//Vanshita
	@Test
	public void addQueries() {
		Queries queries = new Queries();
		queries.setUsername("Vanshita");
		queries.setQueryId("Password Update issue");
		queries.setQuestion("Unable to update my password");
		queriesRepository.save(queries);
		assertNotNull(queriesRepository.findById("Vanshita").get());
	}
	
	@Test
	public void AllQueries() {
		List<Queries> list = queriesRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void getQuery() {
		Queries queries = queriesRepository.findById("Vanshita").get();
		assertEquals("Appupdate", queries.getQuestion());
	}
	@Test
	public void updateQuery() {
		Queries queries = queriesRepository.findById("Vanshita").get();
		queries.setQuestion("Appupdate");
		queriesRepository.save(queries);
		assertNotEquals("Serverdown", queriesRepository.findById("Vanshita").get().getQuestion());
	}

									
	
	
										//Mustafa
	@Test
	public void addCategory() {
		Category policycategory = new Category();
		policycategory.setCategory("Vehicle");
		categoryRepository.save(policycategory);
		assertNotNull(categoryRepository.findById("Vehicle").get());
	}
	
	@Test
	public void categories() {
		List<Category> list = categoryRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void category() {
		Category category = categoryRepository.findById("Health").get();
		assertEquals("Health", category.getCategory());
	}
	@Test
	public void deleteCategory() {
		categoryRepository.deleteById("Health");
		assertThat(categoryRepository.existsById("Health")).isFalse();
	}

	
	
										//Rutrapriya
	
	@Test
	public void addApprovels() {
		Approvals approvals = new Approvals();
		approvals.setRequestId(8);
		approvals.setPolicyId("Insurance");
		Date date = new Date();
		approvals.setDate(date);
		approvals.setStatus("pending");
		approvals.setUserName("Rutrapriya");
		approvalsRepository.save(approvals);
		assertNotNull(approvalsRepository.findById("Rutrapriya").get());
	}
	
	@Test
	public void AllApprovals() {
		List<Approvals> list = approvalsRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void Approval() {
		Approvals approvals = approvalsRepository.findById("Rutrapriya").get();
		assertEquals(8, approvals.getRequestId());
	}

			
	
										//Khaja
	@Test
	public void addApproved() {
		com.insurance.management.model.Approved approved = new com.insurance.management.model.Approved();
		approved.setPolicyId("Insurance");
		approved.setRequestId(2);
		Date date = new Date();
		approved.setDate(date);
		approved.setStatus("Success");
		approved.setUserName("Mohamed Khaja");
		approvedRepository.save(approved);
		assertNotNull(approvedRepository.findById("Mohamed Khaja").get());

	}
	
	@Test
	public void AllApproved() {
		List<com.insurance.management.model.Approved> list = approvedRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void Approved() {
		com.insurance.management.model.Approved approved = approvedRepository.findById("Mohamed Khaja").get();
		assertEquals("Insurance", approved.getPolicyId());
	}

	
	
	
									//Praveen

	@Test
	public void adddisApproved() {
		Disapproved disapproved = new Disapproved();
		disapproved.setPolicyId("Insurance");
		disapproved.setRequestId(2);
		Date date = new Date();
		disapproved.setDate(date);
		disapproved.setStatus("Success");
		disapproved.setUserName("Praveen");
		disapprovedRepository.save(disapproved);
		assertNotNull(disapprovedRepository.findById("Praveen").get());

	}
	@Test
	public void AllDisapproved() {
		List<Disapproved> list = disapprovedRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	public void Disapproved() {
		Disapproved disapproved = disapprovedRepository.findById("Praveen").get();
		assertEquals("Insurance", disapproved.getPolicyId());
	}
}
