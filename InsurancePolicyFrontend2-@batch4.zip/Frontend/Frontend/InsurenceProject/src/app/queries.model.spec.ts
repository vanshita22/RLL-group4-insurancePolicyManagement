import { Queries } from './queries.model';

describe('Queries', () => {
  it('should create an instance', () => {
    expect(new Queries()).toBeTruthy();
  });
});
