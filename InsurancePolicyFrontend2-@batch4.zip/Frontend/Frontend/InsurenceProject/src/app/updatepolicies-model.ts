export class UpdatepoliciesModel {
    
        constructor(
         public policyId:number,
           public policyName:string,
           public amount:string,
           public tenureInYears:string,
           public category:string,
        ){}
    }
    
