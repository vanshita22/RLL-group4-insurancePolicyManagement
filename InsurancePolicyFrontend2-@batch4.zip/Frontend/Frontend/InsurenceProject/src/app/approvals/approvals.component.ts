import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Category } from '../category';
import { CategoryService } from '../category.service';
import { DeletecategoryService } from '../deletecategory.service';

@Component({
  selector: 'app-approvals',
  templateUrl: './approvals.component.html',
  styleUrls: ['./approvals.component.css']
})
export class ApprovalsComponent implements OnInit {

  router: any;

  constructor(private route:Router,private categoryService:CategoryService,private http:HttpClient,private deletecategoryservice: DeletecategoryService) { }
  _url = 'http://localhost:9091/api/v1/categories';
  categories:Category[]=[];

  ngOnInit() {
    this.categoryService.getInsuranceCategory().subscribe(result=>this.categories=result);


}
}
