export class Queries {
    constructor(
       public userName:string,
       public queryid:string,
       public mailid:string,
       public question:string,
    ){}
}
